﻿The SharpGLforWPF package has been renamed to SharpGL.WPF.

The new package has been automatically installed. You can now safely
remove the SharpGLforWinForms package.