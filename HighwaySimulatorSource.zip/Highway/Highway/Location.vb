﻿Public Class Location
    Public x As Double
    Public y As Double
    Public Overloads Function Dist(LocIn As Location)
        Return Math.Sqrt((x - LocIn.x) ^ 2 + (y - LocIn.y) ^ 2)
    End Function
    Public Overloads Function Dist(AgentIn As Vehicle)
        Try
            Return Math.Sqrt((x - AgentIn.Loc.x) ^ 2 + (y - AgentIn.Loc.y) ^ 2)
        Catch
        End Try
        Return 0
    End Function
    Public Sub Move(xin As Double, yin As Double)
        x += xin
        y += yin
    End Sub
    Public Sub MoveTo(xin As Double, yin As Double)
        x = xin
        y = yin
    End Sub
End Class
