﻿Module StatTracker
    Public AverageSpeed As Double
    Public AverageSpeedWeight As Double
    Public SpeedCheckCounter As ULong
    Public VehicleCountTotal As Integer
End Module
