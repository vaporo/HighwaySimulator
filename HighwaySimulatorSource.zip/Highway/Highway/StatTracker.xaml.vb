﻿Public Class StatTracketWindow
    Private Sub Update(sender As Object, e As RoutedEventArgs)
        AverageSpeedLabel.Content = StatTracker.AverageSpeed.ToString
        VehicleCountLabel.Content = StatTracker.VehicleCountTotal.ToString
        VehicleCountNow.Content = Sim.Vehicles.Count.ToString
    End Sub
End Class
