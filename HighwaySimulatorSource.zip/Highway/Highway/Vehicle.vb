﻿Public Class Vehicle
    Public Loc As New Location
    Public Width As Double
    Public Length As Double
    Public DesiredSpeed As Double
    Public CurrentSpeed As Double
    Public Lane As Integer
    Public CurrentHighway As Highway
    Public ProgressAlongHighway As Double
    Public Destination As VehicleSink
    Public Color As Color

    Public SafeDistanceBase As Double = 5 / 3
    Public MinDistanceBase As Double = 1 / 2
    Public ExitLaneChangeDistBase As Double = 20
    Public CurrentState As VehicleStates

    Private NextVehicle As Vehicle
    Private PrevVehicle As Vehicle
    Private DistToNextVehicle As Double
    Private DistToPrevVehicle As Double

    Public Enum VehicleStates
        Travelling
        ThroughSections
        ExitingAtDestination
    End Enum

    Public ReadOnly Property SafeDistance As Double
        Get
            Return SafeDistanceBase * CurrentSpeed + SafeDistanceBase
        End Get
    End Property
    Public ReadOnly Property MinDistance As Double
        Get
            Return MinDistanceBase * CurrentSpeed + MinDistanceBase
        End Get
    End Property
    Public ReadOnly Property ExitLaneChangeDist As Double
        Get
            Dim returnDist As Double = ExitLaneChangeDistBase * CurrentSpeed + ExitLaneChangeDistBase
            If returnDist < 300 Then
                Return 300
            Else
                Return ExitLaneChangeDistBase * CurrentSpeed + ExitLaneChangeDistBase
            End If
        End Get
    End Property

    Public ReadOnly Property Angle
        Get
            Return CurrentHighway.Angle
        End Get
    End Property
    Public ReadOnly Property AngleRads
        Get
            Return CurrentHighway.AngleRads
        End Get
    End Property
    Public Function FindNextVehicleInLane(LaneIn As Integer) As Vehicle
        Dim FoundVehicle As Vehicle = Nothing
        Dim NextHighway As Highway = CurrentHighway.NextSection

        'Search through vehicles in this highway section and the previous and next sections to find the one in front of the vehicle that is nearest.

        Dim PreviousDistance As Double = Double.PositiveInfinity
        For Each Vehicle As Vehicle In CurrentHighway.VehiclesInThisSection
            If Not Vehicle Is Me Then 'Skip over this vehicle's own instance in the list.
                If Vehicle.Lane = LaneIn And Vehicle.ProgressAlongHighway > ProgressAlongHighway Then 'Make sure the vehicle we're looking at is ahead and in the correct lane.
                    Dim FoundDistance As Double = Vehicle.Loc.Dist(Loc)
                    If FoundDistance < PreviousDistance Then 'If we found a vehicle that is closer.
                        FoundVehicle = Vehicle
                        PreviousDistance = FoundDistance
                    End If
                End If
            End If
        Next

        'If we already found a vehicle, then any vehicles in the next section are guaranteed to be further away.
        If Not IsNothing(NextHighway) And IsNothing(FoundVehicle) Then
            For Each Vehicle As Vehicle In NextHighway.VehiclesInThisSection
                If Not Vehicle Is Me Then 'Skip over this vehicle's own instance in the list.
                    If Lane <> -1 And Vehicle.Lane <> -1 Then
                        If NextHighway.PreviousLaneConnections(Vehicle.Lane) = Lane Then 'Check the lane through the lane connections.
                            Dim FoundDistance As Double = Vehicle.Loc.Dist(Loc)
                            If FoundDistance < PreviousDistance Then 'If we found a vehicle that is closer.
                                FoundVehicle = Vehicle
                                PreviousDistance = FoundDistance
                            End If
                        End If
                    End If
                End If
            Next
        End If

        Return FoundVehicle
    End Function


    Public Function FindPreviousVehicleInLane(LaneIn As Integer) As Vehicle
        Dim FoundVehicle As Vehicle = Nothing
        Dim PreviousHighway As Highway = CurrentHighway.PreviousSection

        'Search through vehicles in this highway section and the previous and next sections to find the one in front of the vehicle that is nearest.

        Dim PreviousDistance As Double = Double.PositiveInfinity
        For Each Vehicle As Vehicle In CurrentHighway.VehiclesInThisSection
            If Not Vehicle Is Me Then 'Skip over this vehicle's own instance in the list.
                If Vehicle.Lane = LaneIn And Vehicle.ProgressAlongHighway <= ProgressAlongHighway Then 'Make sure the vehicle we're looking at is ahead and in the correct lane.
                    Dim FoundDistance As Double = Vehicle.Loc.Dist(Loc)
                    If FoundDistance < PreviousDistance Then 'If we found a vehicle that is closer.
                        FoundVehicle = Vehicle
                        PreviousDistance = FoundDistance
                    End If
                End If
            End If
        Next

        'If we already found a vehicle, then any vehicles in the next section are guaranteed to be further away.
        If Not IsNothing(PreviousHighway) And IsNothing(FoundVehicle) Then
            For Each Vehicle As Vehicle In PreviousHighway.VehiclesInThisSection
                If Not Vehicle Is Me Then 'Skip over this vehicle's own instance in the list.
                    If Vehicle.Lane <> -1 Then
                        If PreviousHighway.PreviousLaneConnections(Vehicle.Lane) = Lane Then 'Check the lane through the lane connections.
                            Dim FoundDistance As Double = Vehicle.Loc.Dist(Loc)
                            If FoundDistance < PreviousDistance Then 'If we found a vehicle that is closer.
                                FoundVehicle = Vehicle
                                PreviousDistance = FoundDistance
                            End If
                        End If
                    End If
                End If
            Next
        End If

        Return FoundVehicle
    End Function
    Public Function TryPass(Optional LaneOptions As List(Of Integer) = Nothing)
        Dim LaneChangeSuccess As Boolean = False
        'Select a random direction to try and lane change
        Dim LaneFirstDir As Integer = Math.Sign(Rand.NextDouble * 2 - 1)
        If LaneFirstDir = 0 Then 'Might as well be sure
            LaneFirstDir = 1
        End If

        'Change Lanes
        Dim TargetLane1 = Lane + LaneFirstDir
        Dim TargetLane2 = Lane - LaneFirstDir

        If IsNothing(LaneOptions) OrElse LaneOptions.Contains(TargetLane1) Then
            LaneChangeSuccess = TryLaneChange(LaneFirstDir, SafeDistance)
        End If

        If LaneChangeSuccess Then
            Return LaneChangeSuccess
        Else ' If the last direction didn't work, try the other one.
            If IsNothing(LaneOptions) OrElse LaneOptions.Contains(TargetLane2) Then
                LaneChangeSuccess = TryLaneChange(-LaneFirstDir, SafeDistance)
            End If
        End If
        Return LaneChangeSuccess
    End Function

    Public Function TryLaneChange(Direction As Integer, Optional LaneChangeSafeDistance As Double = 0)

        If Direction = 0 Then 'We're not moving in this case
            Return True
        ElseIf Direction = 1 Or Direction = -1 Then
            Dim TargetLane As Integer = Lane + Direction
            If TargetLane < 0 Or TargetLane > CurrentHighway.LaneCount - 1 Then
                Return False
            End If
            'If the lane we're targeting exists
            If Not (TargetLane > CurrentHighway.LaneCount - 1 Or TargetLane < 0) Then
                Dim NextVehicle As Vehicle = FindNextVehicleInLane(TargetLane)
                Dim PreviousVehicle As Vehicle = FindPreviousVehicleInLane(TargetLane)

                Dim DistToPrev As Double
                Dim DistToNext As Double

                If Not IsNothing(NextVehicle) Then
                    DistToNext = Loc.Dist(NextVehicle) - NextVehicle.Length
                Else
                    DistToNext = Double.PositiveInfinity
                End If

                If Not IsNothing(PreviousVehicle) Then
                    DistToPrev = Loc.Dist(PreviousVehicle) - Length
                Else
                    DistToPrev = Double.PositiveInfinity
                End If

                If DistToNext - LaneChangeSafeDistance > 0 And DistToPrev > 0 Then
                    Lane = TargetLane
                    Return True
                Else
                    Return False
                End If
            Else
                Return False
            End If
        Else
            Return False
        End If
        Return False
    End Function
    Public Sub UpdateState()
        'Update the Vehicle's current state.
        If Destination.AtHighway Is CurrentHighway And CurrentHighway.Length - ProgressAlongHighway < ExitLaneChangeDist Then
            CurrentState = VehicleStates.ExitingAtDestination
        ElseIf Not Destination.AtHighway Is CurrentHighway And CurrentHighway.Length - ProgressAlongHighway < ExitLaneChangeDist Then
            CurrentState = VehicleStates.ThroughSections
        Else
            CurrentState = VehicleStates.Travelling
        End If

    End Sub
    Public Sub AdjustSpeed(Optional Vin As Double = -1)
        'Adjust speed
        If Vin >= 0 Then
            CurrentSpeed = Vin
            Exit Sub
        End If
        Dim Safety As Double = 3 + 0.25 * CurrentSpeed
        Dim DistToRearOfNextVehicle As Double
        If IsNothing(NextVehicle) Then
            DistToRearOfNextVehicle = Double.PositiveInfinity
        Else
            DistToRearOfNextVehicle = DistToNextVehicle - NextVehicle.Length - Safety
        End If

        If DistToRearOfNextVehicle > SafeDistance Then
            CurrentSpeed = DesiredSpeed
        ElseIf DistToRearOfNextVehicle < SafeDistance And DistToRearOfNextVehicle > MinDistance Then
            CurrentSpeed = NextVehicle.CurrentSpeed + (DesiredSpeed - NextVehicle.CurrentSpeed) * (DistToRearOfNextVehicle - MinDistance) / (SafeDistance - MinDistance)
        ElseIf DistToRearOfNextVehicle > 0 Then
            CurrentSpeed = NextVehicle.CurrentSpeed
        Else 'We're inside the next vehicle. Better stop and let it drive forward a bit or we'll get caught by the reality cops.
            CurrentSpeed = 0
        End If
    End Sub
    Public Sub MoveForward()
        ProgressAlongHighway += CurrentSpeed * Sim.TickLength
        UpdateLocation()
    End Sub
    Public Sub UpdateLocation()
        Loc.x = CurrentHighway.StartPos.x + Math.Cos(Angle * Math.PI / 180) * ProgressAlongHighway
        Loc.y = CurrentHighway.StartPos.y + Math.Sin(Angle * Math.PI / 180) * ProgressAlongHighway
    End Sub
    Public Sub TryTransferToNextSection()
        If ProgressAlongHighway > CurrentHighway.Length And CurrentHighway.NextLaneConnections(Lane) <> -1 Then
            Dim SpeedRatio = DesiredSpeed / CurrentHighway.SpeedLimit
            DesiredSpeed = CurrentHighway.NextSection.SpeedLimit * SpeedRatio
            ProgressAlongHighway -= CurrentHighway.Length
            'There seems to be an edge case where a vehicle can have its lane set to -1.
            If Lane = -1 Then
                Lane = 0
            Else
                Lane = CurrentHighway.NextLaneConnections(Lane)
            End If
            Try
                CurrentHighway.VehiclesInThisSection.Remove(Me)
            Catch
            End Try
            CurrentHighway = CurrentHighway.NextSection
            CurrentHighway.VehiclesInThisSection.Add(Me)
            UpdateLocation()
        End If
    End Sub
    Public Sub TickTravelling()
        Dim TryPassResult As Boolean
        If DistToNextVehicle < SafeDistance Then
            TryPassResult = TryPass(CurrentHighway.NonEndingLanes)
        End If
        AdjustSpeed()
        MoveForward()
        UpdateState()
    End Sub
    Public Sub TickThroughSections()
        'If we're in a lane that ends.
        If CurrentHighway.EndingLanes.Contains(Lane) Then
            TryLaneChange(Math.Sign(CurrentHighway.NonEndingLanes(0) - Lane)) 'Try to change into a lane that isn't ending
        Else
            'If we're getting close to the next vehicle.
            If DistToNextVehicle < SafeDistance Then
                TryPass(CurrentHighway.NonEndingLanes)
            End If
        End If
        AdjustSpeed()
        MoveForward()

        TryTransferToNextSection()
        UpdateState()
    End Sub
    Public Sub TickExitingAtDestination()
        If Lane <> Destination.AtLane Then
            TryLaneChange(Math.Sign(Destination.AtLane - Lane)) 'Try to change into the lane of our destination
        Else
            'Continue onward. Nothing needs done
        End If

        'For the sake of this simulation, we'll assume that this if the vehicle reaches any sink on this highway section, it will count as the correct exit.

        'If we're in the lane with a sink and we're good to exit.
        Dim CurrentSink As VehicleSink = CurrentHighway.GetSink(Lane)
        If Not IsNothing(CurrentSink) AndAlso CurrentSink.NextOpening <= Sim.SimTime And ProgressAlongHighway >= CurrentHighway.Length Then
            CurrentSink.TrySinkVehicle()
            'We can't erase the vehicles while we're iterating through the list, so remember them to delete later.
            Sim.RemoveList.Add(Me)
            'If we're at the end of the highway but not at a usable sink
        ElseIf ProgressAlongHighway >= CurrentHighway.Length Then
            AdjustSpeed(0)
            ProgressAlongHighway = CurrentHighway.Length
            UpdateLocation()
        Else 'We're not at the end of the highway
            AdjustSpeed()
            MoveForward()
        End If
        UpdateState()

    End Sub
    Public Sub Tick()

        NextVehicle = FindNextVehicleInLane(Lane)
        If IsNothing(NextVehicle) Then
            DistToNextVehicle = Double.PositiveInfinity
        Else
            DistToNextVehicle = Loc.Dist(NextVehicle)
        End If
        'We don't actually need to find the previous vehicle, so it's removed for efficiency's sake.
        'PrevVehicle = FindPreviousVehicleInLane(Lane)
        'DistToPrevVehicle = Loc.Dist(PrevVehicle)

        Select Case CurrentState
            Case VehicleStates.ExitingAtDestination
                TickExitingAtDestination()
            Case VehicleStates.ThroughSections
                TickThroughSections()
            Case VehicleStates.Travelling
                TickTravelling()
        End Select

        CollectStatistics()

    End Sub
    Sub CollectStatistics()
        AverageSpeedWeight += CurrentSpeed
        SpeedCheckCounter += 1
        AverageSpeed = AverageSpeedWeight / SpeedCheckCounter
    End Sub
End Class
