﻿Public Class Highway
    Public Name As String
    Public StartPos As Location
    Public EndPos As Location
    Public SpeedLimit As Double

    Public VehiclesInThisSection As New List(Of Vehicle)

    Public SourceList As New List(Of VehicleSource)
    Public SourceWeights() As Double
    Public SinkDelays() As Double
    Public SinkList As New List(Of VehicleSink)
    Public NonEndingLanes As New List(Of Integer)
    Public EndingLanes As New List(Of Integer)

    Public ReadOnly Property LaneCount As Integer
    Public ReadOnly Property Length
        Get
            Return StartPos.Dist(EndPos)
        End Get
    End Property
    Public ReadOnly Property Angle
        Get
            Return Math.Atan2(EndPos.y - StartPos.y, EndPos.x - StartPos.x) / (Math.PI) * 180
        End Get
    End Property
    Public ReadOnly Property AngleRads
        Get
            Return Math.Atan2(EndPos.y - StartPos.y, EndPos.x - StartPos.x)
        End Get
    End Property
    Public NextSection As Highway
    Public PreviousSection As Highway
    'Stores the which lanes in this highway section connect to which lanes in the next highway section.
    'A -1 indicates an endpoint.
    Public NextLaneConnections() As Integer
    'Stores the which lanes in this highway section connect to which lanes in the previous highway section.
    'A -1 indicates a vehicle source.
    Public PreviousLaneConnections() As Integer

    'Set up this section of highway
    'Assuming that if a previous highway is inputted, there will also be a set of lane connections inputted.
    Public Sub New(NameIn As String, StartIn As Location, EndIn As Location, SpeedLimitIn As Double, LanesIn As UInteger, SourceWeightIn() As Double, Optional ConnectsToPrevious As Highway = Nothing, Optional PreviousLaneConnectionsIn() As Integer = Nothing, Optional SinkDelaysIn() As Double = Nothing)
        Name = NameIn
        SpeedLimit = SpeedLimitIn
        StartPos = StartIn
        EndPos = EndIn
        LaneCount = LanesIn
        SourceWeights = SourceWeightIn
        If Not IsNothing(ConnectsToPrevious) Then
            PreviousSection = ConnectsToPrevious
            PreviousLaneConnections = PreviousLaneConnectionsIn
            SinkDelays = SinkDelaysIn
            'Set up lane connections to the previous section.
            PreviousSection.NextSection = Me
            Dim i As Integer = 0
            For i = 0 To PreviousLaneConnections.Count - 1
                Dim Lane As Integer = PreviousLaneConnections(i)
                'Go into the previous section and indicate which lanes should connect to which
                Try
                    If Lane <> -1 Then
                        PreviousSection.NextLaneConnections(Lane) = i
                    End If
                Catch

                End Try
            Next
        Else 'Set all previous lanes to sources if there is no previous highway to connect to.
            PreviousSection = Nothing
            ReDim PreviousLaneConnections(LaneCount - 1)
            For i = 0 To PreviousLaneConnections.Count - 1
                PreviousLaneConnections(i) = -1
            Next
        End If


        SetUpSources()

        'By default, a new highway section ends in sinks.
        ReDim NextLaneConnections(LaneCount - 1)
        For i = 0 To NextLaneConnections.Count - 1
            NextLaneConnections(i) = -1
        Next
    End Sub

    'Sub to set up the source objects
    Public Sub SetUpSources()
        'Erase the sources from the main list
        For Each Source In SourceList
            Try
                Sim.VehicleSources.Remove(Source)
            Catch ex As Exception

            End Try
        Next
        SourceList.Clear()
        'Set up Vehicle Sources
        For i = 0 To PreviousLaneConnections.Count - 1
            If PreviousLaneConnections(i) = -1 AndAlso Not IsNothing(SourceWeights) AndAlso SourceWeights(i) <> -1 Then

                Dim NewSource As New VehicleSource
                NewSource.AtHighway = Me
                NewSource.AtLane = i
                NewSource.LaneWeight = SourceWeights(i)
                Sim.VehicleSources.Add(NewSource)
                SourceList.Add(NewSource)
            End If
        Next
    End Sub
    'Sub to set up the sink objects
    Public Sub SetUpSinks()
        'Erase the sinks from the main list
        For Each Sink In SinkList
            Try
                Sim.VehicleSinks.Remove(Sink)
            Catch ex As Exception

            End Try
        Next
        SinkList.Clear()
        'Set up new Vehicle Sinks
        For i = 0 To LaneCount - 1
            If NextLaneConnections(i) = -1 AndAlso Not IsNothing(SinkDelays) AndAlso SinkDelays(i) <> -1 Then
                Dim NewSink As New VehicleSink
                NewSink.AtHighway = Me
                NewSink.AtLane = i
                NewSink.WaitTime = SinkDelays(i)
                NewSink.NextOpening = 0
                Sim.VehicleSinks.Add(NewSink)
                SinkList.Add(NewSink)
            End If
        Next
        ListEndingAndNotEndingLanes()
    End Sub
    Public Sub ListEndingAndNotEndingLanes()
        EndingLanes.Clear()
        NonEndingLanes.Clear()
        'Compile a list of the lanes that end in a sink and lanes that don't end in a sink for easy access later
        For j = 0 To NextLaneConnections.Count - 1
            If NextLaneConnections(j) = -1 Then
                EndingLanes.Add(j)
            Else
                NonEndingLanes.Add(j)
            End If
        Next
    End Sub
    Public Function GetSink(LaneIn As Integer) As VehicleSink
        For Each Sink In SinkList
            If Sink.AtLane = LaneIn Then
                Return Sink
            End If
        Next
        Return Nothing
    End Function
End Class

Public Class VehicleSource
    Public AtHighway As Highway
    Public AtLane As Integer
    Public LaneWeight As Double
    Public TimeofNextVehicle As Double = 0
    'Return true if a vehicle was generated
    Public Function TryGenerateVehicle() As Boolean
        Dim VehicleConflict As Boolean = False
        'Check to make sure that there isn't still a vehicle blocking the source before generating a new one.
        For Each Vehicle In AtHighway.VehiclesInThisSection
            If Vehicle.ProgressAlongHighway - Vehicle.Length < 0 And Vehicle.Lane = AtLane Then
                VehicleConflict = True
                Exit For
            End If
        Next
        If Sim.SimTime >= TimeofNextVehicle And LaneWeight <> -1 And Not VehicleConflict Then
            Dim NewVehicle As New Vehicle
            NewVehicle.Lane = AtLane
            NewVehicle.CurrentHighway = AtHighway
            NewVehicle.ProgressAlongHighway = 0
            NewVehicle.Width = 8
            NewVehicle.Length = 15
            NewVehicle.DesiredSpeed = NewVehicle.CurrentHighway.SpeedLimit + NewVehicle.CurrentHighway.SpeedLimit * 0.1 * (Rand.NextDouble * 2 - 1)
            NewVehicle.CurrentSpeed = NewVehicle.DesiredSpeed
            NewVehicle.Loc.x = AtHighway.StartPos.x
            NewVehicle.Loc.y = AtHighway.StartPos.y

            Dim RandColor(2) As Byte
            Rand.NextBytes(RandColor)
            NewVehicle.Color.R = RandColor(0)
            NewVehicle.Color.G = RandColor(1)
            NewVehicle.Color.B = RandColor(2)

            'Search forward and find all possible destinations for this car.
            Dim ForwardDestinations As New List(Of VehicleSink)
            Dim TestHighway As Highway = NewVehicle.CurrentHighway

            Do
                For Each Sink In TestHighway.SinkList
                    If Sink.WaitTime <> -1 Then
                        ForwardDestinations.Add(Sink)
                    End If
                Next
                TestHighway = TestHighway.NextSection
            Loop While Not IsNothing(TestHighway)

            Dim RandNumber As Integer = Math.Floor(Rand.NextDouble * ForwardDestinations.Count)
            NewVehicle.Destination = ForwardDestinations(RandNumber)

            Sim.Vehicles.Add(NewVehicle)
            NewVehicle.CurrentHighway.VehiclesInThisSection.Add(NewVehicle) 'Add to highway
            TimeofNextVehicle = Math.Abs(Math.Log(Rand.NextDouble) * LaneWeight) + Sim.SimTime

            VehicleCountTotal += 1
            Return True
        Else
            Return False
        End If
    End Function
End Class
Public Class VehicleSink
    Public AtHighway As Highway
    Public AtLane As Integer
    Public WaitTime As Double
    Public NextOpening As Double
    Public Function TrySinkVehicle() As Boolean
        If NextOpening <= Sim.SimTime Then
            NextOpening = Sim.SimTime + WaitTime
            Return True
        End If
        Return False
    End Function
End Class
