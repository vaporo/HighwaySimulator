﻿
Class MainWindow
    Private Sub StartSimulation(sender As Object, e As RoutedEventArgs)

        Sim.TickLength = CDbl(TickLengthTextBox.Text)
        Sim.RunLength = CDbl(RunLengthTextBox.Text)
        Sim.Rate = CDbl(RateTextBox.Text)
        Sim.SimulationLoop()
    End Sub

    Public LaneWidth As Double = 15
    Public EndTruncation As Double = 30

    Dim rotatePyramid As Single = 0
    Dim rquad As Single = 0

    Private Sub DoDraw(sender As Object, args As SharpGL.SceneGraph.OpenGLEventArgs)
        glargs = args
        Draw()
    End Sub
    Dim glargs As SharpGL.SceneGraph.OpenGLEventArgs
    Public Sub Draw()
        Dim gl As SharpGL.OpenGL = glargs.OpenGL
        gl.Clear(SharpGL.OpenGL.GL_COLOR_BUFFER_BIT Or SharpGL.OpenGL.GL_DEPTH_BUFFER_BIT)

        gl.LoadIdentity()
        gl.Scale(0.1F * ZoomFactor, 0.1F * ZoomFactor, 1.0F)
        gl.LookAt(-CSng(XTranslateValue), CSng(YTranslateValue), 10.0F, -CSng(XTranslateValue), CSng(YTranslateValue), 0F, 0F, 1.0F, 0F)
        'gl.Translate(0.1F * FrameCount, 0.1F * FrameCount, 0F)
        For Each Vehicle In Sim.Vehicles
            gl.PushMatrix()
            'Render vehicles in different lanes in different positions.
            gl.Translate(Vehicle.Loc.x, Vehicle.Loc.y, 0F)
            gl.Rotate(0F, 0F, Vehicle.Angle)
            gl.Translate(0F, LaneWidth * Vehicle.Lane, 0F)

            gl.Begin(SharpGL.OpenGL.GL_QUADS)

            gl.Color(Vehicle.Color.R, Vehicle.Color.G, Vehicle.Color.B)
            gl.Vertex(0F, -Vehicle.Width / 2, 0F)
            gl.Vertex(0F, Vehicle.Width / 2, 0F)
            gl.Vertex(-Vehicle.Length, Vehicle.Width / 2, 0F)
            gl.Vertex(-Vehicle.Length, -Vehicle.Width / 2, 0F)
            gl.End()

            gl.PopMatrix()

        Next

        For Each Highway In Sim.Highways
            gl.PushMatrix()
            gl.Translate(Highway.StartPos.x, Highway.StartPos.y, 0)
            gl.Rotate(0F, 0F, Highway.Angle)
            For i = 0 To Highway.LaneCount - 1

                'gl.Rotate(Highway.Angle, 0.0F, 1.0F, 0.0F)


                gl.Begin(SharpGL.OpenGL.GL_LINES)

                gl.Color(1.0F, 1.0F, 1.0F)
                gl.Vertex(0, i * LaneWidth, -0.1F)
                gl.Vertex(Highway.Length - EndTruncation, i * LaneWidth, -0.1F)

                'gl.Vertex(CSng(Highway.StartPos.x + i * LaneWidth * Math.Cos((Highway.Angle + 90) * Math.PI / 180)), CSng(Highway.StartPos.y + i * LaneWidth * Math.Sin((Highway.Angle + 90) * Math.PI / 180)), -0.1F)
                'gl.Vertex(CSng(Highway.EndPos.x + i * LaneWidth * Math.Cos((Highway.Angle + 90) * Math.PI / 180)), CSng(Highway.EndPos.y + i * LaneWidth * Math.Sin((Highway.Angle + 90) * Math.PI / 180)), -0.1F)

                gl.End()
            Next
            gl.PopMatrix()

            'Draw sinks
            For Each Sink In Highway.SinkList
                gl.PushMatrix()
                gl.Translate(Highway.StartPos.x, Highway.StartPos.y, -0.05F)
                gl.Rotate(0F, 0F, Highway.Angle)
                gl.Translate(Highway.Length - EndTruncation, Sink.AtLane * LaneWidth, 0F)

                gl.Begin(SharpGL.OpenGL.GL_QUADS)
                gl.Color(1.0F, 0F, 0F)
                gl.Vertex(5.0F, 5.0F, 0F)
                gl.Vertex(-5.0F, 5.0F, 0F)
                gl.Vertex(-5.0F, -5.0F, 0F)
                gl.Vertex(5, -5, 0F)

                gl.End()
                gl.PopMatrix()
            Next

            'Draw sources
            For Each Source In Highway.SourceList
                gl.PushMatrix()

                gl.Translate(Highway.StartPos.x, Highway.StartPos.y, -0.05F)
                gl.Rotate(0F, 0F, Highway.Angle)
                gl.Translate(0F, Source.AtLane * LaneWidth, 0F)

                gl.Begin(SharpGL.OpenGL.GL_QUADS)
                gl.Color(0F, 1.0F, 0F)
                gl.Vertex(5.0F, 5.0F, 0F)
                gl.Vertex(-5.0F, 5.0F, 0F)
                gl.Vertex(-5.0F, -5.0F, 0F)
                gl.Vertex(5, -5, 0F)

                gl.End()
                gl.PopMatrix()
            Next

            For i = 0 To Highway.NextLaneConnections.Count - 1
                If Highway.NextLaneConnections(i) <> -1 Then
                    gl.Begin(SharpGL.OpenGL.GL_LINES)
                    gl.Color(1.0F, 0.5F, 0F)

                    gl.PushMatrix()
                    'gl.Translate(Highway.EndPos.x, Highway.EndPos.y, 0)
                    'gl.Rotate(0F, 0F, Highway.Angle)
                    'gl.Vertex(Highway.Length - EndTruncation, i * LaneWidth, -0.1F)


                    'gl.Vertex(Highway.EndPos.x - EndTruncation * Math.Sin(Highway.AngleRads) + i * LaneWidth * Math.Cos(Highway.AngleRads), Highway.EndPos.y - EndTruncation * Math.Cos(Highway.AngleRads) + i * LaneWidth * Math.Sin(Highway.AngleRads), -0.1F)
                    gl.Vertex(Highway.EndPos.x - i * LaneWidth * Math.Sin(Highway.AngleRads) - EndTruncation * Math.Cos(Highway.AngleRads), Highway.EndPos.y + i * LaneWidth * Math.Cos(Highway.AngleRads) - EndTruncation * Math.Sin(Highway.AngleRads), -0.1F)
                    gl.Vertex(Highway.NextSection.StartPos.x - LaneWidth * Highway.NextLaneConnections(i) * Math.Sin(Highway.NextSection.AngleRads), Highway.NextSection.StartPos.y + LaneWidth * Highway.NextLaneConnections(i) * Math.Cos(Highway.NextSection.AngleRads), -0.1F)
                    'gl.Vertex(Highway.NextSection.StartPos.x, Highway.NextSection.StartPos.y, -0.1F)
                    'gl.Vertex(0F, 0F, -0.1F)

                    'gl.PopMatrix()

                    'gl.PushMatrix()
                    'gl.Translate(Highway.NextSection.StartPos.x, Highway.NextSection.StartPos.y, 0)
                    'gl.Rotate(0F, 0F, Highway.NextSection.Angle)
                    'gl.Vertex(0F, Highway.NextLaneConnections(i) * LaneWidth, -0.1F)
                    gl.PopMatrix()

                    gl.End()
                End If
            Next
        Next
            FrameCount = FrameCount + 1
        gl.Flush()

    End Sub
    Dim FrameCount As Long = 0

    Private Sub TestDoDraw(sender As Object, args As SharpGL.SceneGraph.OpenGLEventArgs)
        Dim gl As SharpGL.OpenGL = args.OpenGL
        gl.Clear(SharpGL.OpenGL.GL_COLOR_BUFFER_BIT Or SharpGL.OpenGL.GL_DEPTH_BUFFER_BIT)
        gl.LoadIdentity()
        gl.Translate(-1.5F, 0.0F, -6.0F)
        gl.Rotate(rotatePyramid, 0.0F, 1.0F, 0.0F)

        gl.Begin(SharpGL.OpenGL.GL_TRIANGLES)

        gl.Color(1.0F, 0.0F, 0.0F)
        gl.Vertex(0.0F, 1.0F, 0.0F)
        gl.Color(0.0F, 1.0F, 0.0F)
        gl.Vertex(-1.0F, -1.0F, 1.0F)
        gl.Color(0.0F, 0.0F, 1.0F)
        gl.Vertex(1.0F, -1.0F, 1.0F)

        gl.Color(1.0F, 0.0F, 0.0F)
        gl.Vertex(0.0F, 1.0F, 0.0F)
        gl.Color(0.0F, 0.0F, 1.0F)
        gl.Vertex(1.0F, -1.0F, 1.0F)
        gl.Color(0.0F, 1.0F, 0.0F)
        gl.Vertex(1.0F, -1.0F, -1.0F)

        gl.Color(1.0F, 0.0F, 0.0F)
        gl.Vertex(0.0F, 1.0F, 0.0F)
        gl.Color(0.0F, 1.0F, 0.0F)
        gl.Vertex(1.0F, -1.0F, -1.0F)
        gl.Color(0.0F, 0.0F, 1.0F)
        gl.Vertex(-1.0F, -1.0F, -1.0F)

        gl.Color(1.0F, 0.0F, 0.0F)
        gl.Vertex(0.0F, 1.0F, 0.0F)
        gl.Color(0.0F, 0.0F, 1.0F)
        gl.Vertex(-1.0F, -1.0F, -1.0F)
        gl.Color(0.0F, 1.0F, 0.0F)
        gl.Vertex(-1.0F, -1.0F, 1.0F)

        gl.End()

        gl.LoadIdentity()

        gl.Translate(1.5F, 0.0F, -7.0F)
        gl.Rotate(rquad, 1.0F, 1.0F, 1.0F)
        gl.Begin(SharpGL.OpenGL.GL_QUADS)

        gl.Color(0.0F, 1.0F, 0.0F)
        gl.Vertex(1.0F, 1.0F, -1.0F)
        gl.Vertex(-1.0F, 1.0F, -1.0F)
        gl.Vertex(-1.0F, 1.0F, 1.0F)
        gl.Vertex(1.0F, 1.0F, 1.0F)

        gl.Color(1.0F, 0.5F, 0.0F)
        gl.Vertex(1.0F, -1.0F, 1.0F)
        gl.Vertex(-1.0F, -1.0F, 1.0F)
        gl.Vertex(-1.0F, -1.0F, -1.0F)
        gl.Vertex(1.0F, -1.0F, -1.0F)

        gl.Color(1.0F, 0.0F, 0.0F)
        gl.Vertex(1.0F, 1.0F, 1.0F)
        gl.Vertex(-1.0F, 1.0F, 1.0F)
        gl.Vertex(-1.0F, -1.0F, 1.0F)
        gl.Vertex(1.0F, -1.0F, 1.0F)

        gl.Color(1.0F, 1.0F, 0.0F)
        gl.Vertex(1.0F, -1.0F, -1.0F)
        gl.Vertex(-1.0F, -1.0F, -1.0F)
        gl.Vertex(-1.0F, 1.0F, -1.0F)
        gl.Vertex(1.0F, 1.0F, -1.0F)

        gl.Color(0.0F, 0.0F, 1.0F)
        gl.Vertex(-1.0F, 1.0F, 1.0F)
        gl.Vertex(-1.0F, 1.0F, -1.0F)
        gl.Vertex(-1.0F, -1.0F, -1.0F)
        gl.Vertex(-1.0F, -1.0F, 1.0F)

        gl.Color(1.0F, 0.0F, 1.0F)
        gl.Vertex(1.0F, 1.0F, -1.0F)
        gl.Vertex(1.0F, 1.0F, 1.0F)
        gl.Vertex(1.0F, -1.0F, 1.0F)
        gl.Vertex(1.0F, -1.0F, -1.0F)

        gl.End()

        gl.Flush()

        rotatePyramid += 3.0F
        rquad -= 3.0F
    End Sub
    Dim StatWindow As New StatTracketWindow

    Private Sub Initialize(sender As Object, e As RoutedEventArgs)
        Sim = New Simulator
        Main = Me
        Sim.InitializeSimulator()
        Sim.ReadInHighwayData()
        StatWindow.Show()
    End Sub

    Private Sub TextBox_TextChanged(sender As Object, e As TextChangedEventArgs)

    End Sub

    Public ZoomFactor As Double = 1
    'Zoom Function
    Private Sub DoZoom(sender As Object, e As MouseWheelEventArgs)
        If e.Delta > 0 Then
            ZoomFactor = 0.75 ^ ((e.Delta / 120) + 1) * ZoomFactor
        Else
            ZoomFactor = 0.75 ^ ((e.Delta / 120) - 1) * ZoomFactor
        End If
    End Sub
    Private LastPosition As Point

    Private XTranslateValue As Double = 0
    Private YTranslateValue As Double = 0

    'Pan Function
    Private Sub DoDrag(sender As Object, e As MouseEventArgs)

        If e.LeftButton = MouseButtonState.Pressed Then
            If IsNothing(LastPosition) Then
                LastPosition = e.GetPosition(sender)
            End If
            '4.7 is a factor found by trial and error that results in accurrate drags
            XTranslateValue += (e.GetPosition(sender).X - LastPosition.X) / (ZoomFactor * 4.7 / (793.6 / MainGLWindow.ActualWidth))
            YTranslateValue += (e.GetPosition(sender).Y - LastPosition.Y) / (ZoomFactor * 4.7 / (400.8 / MainGLWindow.ActualHeight))
            LastPosition = e.GetPosition(sender)
        End If
    End Sub
    'When we start dragging the view
    Private Sub DragStart(sender As Object, e As MouseButtonEventArgs)
        LastPosition = e.GetPosition(sender)
    End Sub

    Private Sub DragEnd(sender As Object, e As MouseButtonEventArgs)
        LastPosition = Nothing
    End Sub
End Class
