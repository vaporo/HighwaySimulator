﻿Module MainSimulator
    Public Sim As Simulator
    Public Main As MainWindow
    Public Rand As New Random
    'Public Sub DoEvents()
    '    Application.Current.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, New Action(delegate { }))
    'End Sub


End Module
Class Simulator

    Public FrameTimer As New Timers.Timer

    Public Vehicles As New List(Of Vehicle) 'The list of all vehicles in the model
    Public Highways As New List(Of Highway) 'The list of all highways in the model
    Public VehicleSources As New List(Of VehicleSource) 'The list of all vehicle sources in the model
    Public VehicleSinks As New List(Of VehicleSink) 'The list of all vehicle sources in the model

    Public TickLength As Double = 0.05
    Public RunLength As Double = 1000
    Public Rate As Double = 1

    Public SimTime As Double

    Public RemoveList As New List(Of Vehicle)

    Private RunSim As Boolean = False
    Public ReadOnly Property IsSimRunning
        Get
            Return RunSim
        End Get
    End Property
    Public Sub StartSim()

        SimulationLoop()
    End Sub
    Public Sub StopSim()
        RunSim = False
    End Sub

    'The right way to do this would be to have the renderer and simulation logic on separate threads, but I'm not that ambitious right now.
    Public Sub SimulationLoop()
        Dim FrameInterval As Double = 1 / 60
        Dim FrameStartTime As Date = Now
        Dim FrameEndTime As Date = FrameStartTime.AddSeconds(FrameInterval)

        While SimTime < RunLength
            Dim TickRealStartTime As Date = Now
            Dim TickRealEndTime As Date = FrameStartTime.AddSeconds(TickLength / Rate)
            'Hacky solution, but I'm in a hurry
            DoTick()
            'Render the next frame if it is time.
            If Now >= FrameEndTime Then
                System.Windows.Forms.Application.DoEvents()
                FrameStartTime = Now
                FrameEndTime = FrameStartTime.AddSeconds(FrameInterval)
            End If
            While Now < TickRealEndTime
            End While
        End While
    End Sub
    Public Sub DoTick()
        TickVehicleSources()
        TickVehicles()
        SimTime += TickLength
    End Sub

    Private Sub TickVehicleSources()
        For Each Source In VehicleSources
            Source.TryGenerateVehicle()
        Next
    End Sub

    Private Sub TickVehicles()
        'Move the vehicles along their paths
        For Each Vehicle In Vehicles
            Vehicle.Tick()
        Next
        'Delete unneeded vehicles
        For Each RemovedVehicle In RemoveList
            RemovedVehicle.CurrentHighway.VehiclesInThisSection.Remove(RemovedVehicle)
            Vehicles.Remove(RemovedVehicle)
        Next
        RemoveList.Clear()
    End Sub

    Public Sub ReadInHighwayData()
        Dim PreviousSection As Highway = Nothing
        'Read in the data about the highways
        'Format: Name#Startpos#Endpos#SpeedLimit#LaneCount#LaneConnections#SourceLaneWeighting#SinkLaneDelays
        Dim FilePath As String = System.IO.Directory.GetCurrentDirectory() & "\Highways.txt"
        Dim InputFiles() As String = System.IO.Directory.GetFiles(System.IO.Directory.GetCurrentDirectory(), "*.txt")

        If InputFiles.Count > 1 Then
            Dim FileSelectWindow As New SelectHighwayWindow
            For Each InputFile In InputFiles
                FileSelectWindow.SelectorBox.Items.Add(InputFile)
            Next
            FileSelectWindow.ShowDialog()
            FilePath = FileSelectWindow.SelectorBox.SelectedItem
        Else
            FilePath = InputFiles(0)
        End If

        'Dim InText As String = System.IO.File.ReadAllText(FilePath)
        Dim SectionList() As String = System.IO.File.ReadAllLines(FilePath)
        'Skip the first header line
        For k = 1 To SectionList.Count - 1
            Dim Section As String = SectionList(k)
            Dim HighwayData() As String = Section.Split("#")

            Dim HighwayName As String = HighwayData(0)
            Dim StartPos As New Location
            StartPos.x = CDbl(HighwayData(1).Split(",")(0))
            StartPos.y = CDbl(HighwayData(1).Split(",")(1))
            Dim EndPos As New Location
            EndPos.x = CDbl(HighwayData(2).Split(",")(0))
            EndPos.y = CDbl(HighwayData(2).Split(",")(1))
            Dim SpeedLimit As Double = CDbl(HighwayData(3))
            Dim LaneCount As Integer = CInt(HighwayData(4))
            Dim LaneStringList() As String = HighwayData(5).Split(",")
            Dim LaneList(LaneStringList.Count - 1) As Integer
            For i = 0 To LaneStringList.Count - 1
                LaneList(i) = CInt(LaneStringList(i))
            Next
            Dim SourceWeightStrings() As String = HighwayData(6).Split(",")
            Dim SourceWeight(LaneList.Count - 1) As Double
            Dim j As Integer = 0
            For i = 0 To LaneList.Count - 1
                If LaneList(i) = -1 Then
                    SourceWeight(i) = CDbl(SourceWeightStrings(j))
                    j = j + 1
                Else
                    SourceWeight(i) = 0
                End If
            Next
            Dim SinkDelayStrings() As String = HighwayData(7).Split(",")
            Dim SinkDelays(LaneList.Count - 1) As Double
            j = 0
            For i = 0 To LaneList.Count - 1
                Try
                    SinkDelays(i) = CDbl(SinkDelayStrings(i))
                    j = j + 1
                Catch
                    SinkDelays(i) = 0
                End Try
            Next
            'Create a new Highway object with the read in data.
            Dim NewHighway As New Highway(HighwayName, StartPos, EndPos, SpeedLimit, LaneCount, SourceWeight, PreviousSection, LaneList, SinkDelays)
            Highways.Add(NewHighway)
            PreviousSection = NewHighway
        Next

        'Set up the sinks objects on the highway sections.
        For Each Highway In Highways
            Highway.SetUpSinks()
        Next
    End Sub
    Public Sub InitializeSimulator()
    End Sub
End Class
